import 'package:flutter/material.dart';

Color bgColor = const Color(0xff252528);
Color buttonColor = const Color(0xff3c4043);

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OneRemote',
      theme: ThemeData(
        primaryColor: bgColor,
      ),
      home: Scaffold(
        body: BodyLayout(),
        backgroundColor: bgColor,
      ),
    );
  }
}

class BodyLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return _mainMenu(context);
  }
}

Widget _mainMenu(BuildContext context) {
  return ListView(
    children: <Widget>[
      Container(
        margin: EdgeInsets.all(20.0),
        padding: EdgeInsets.all(20.0),
        constraints: BoxConstraints(maxWidth: 766.0, minWidth: 119.0),
        alignment: Alignment.topCenter,
        child: Image.network('https://i.imgur.com/B5lKfG5.png'),
      ),
      mainMenuButton(context, "Devices", Icons.settings_remote),
      mainMenuButton(context, "Routines", Icons.star_border),
      mainMenuButton(context, "Settings", Icons.tune),
      mainMenuButton(context, "Sign Out", Icons.move_to_inbox),
    ],
  );
}

Widget mainMenuButton(BuildContext context, String label, IconData labelIcon) {
  return new Container(
    width: MediaQuery.of(context).size.width,
    margin: EdgeInsets.only(top: 10.0, left: 25.0, right: 25.0),

    decoration: new BoxDecoration(
      color: buttonColor,
      borderRadius: new BorderRadius.circular(25.0),
    ),
    child: new ListTile(
        leading: Icon(labelIcon, color: Colors.white, size: 33.0),

        title: Text(label,
            style: TextStyle(color: Colors.white, fontSize:28.0)),
        onTap: () {
          Devices();
        }),
  );
}


class Devices extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new MyApp(),
    );
  }
}