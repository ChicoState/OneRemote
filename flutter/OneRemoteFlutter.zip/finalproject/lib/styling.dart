import 'package:flutter/material.dart';

Color bgColor = const Color(0xff252528);
Color buttonColor = const Color(0xff3c4043);

Widget whiteText(String displayText){
  return Text(
    displayText,
    overflow: TextOverflow.ellipsis,
    style: TextStyle(color: Colors.white),
  );
}

class SlideRightRoute extends PageRouteBuilder {
  final Widget page;
  SlideRightRoute({this.page})
      : super(
    pageBuilder: (
        BuildContext context,
        Animation<double> animation,
        Animation<double> secondaryAnimation,
        ) =>
    page,
    transitionsBuilder: (
        BuildContext context,
        Animation<double> animation,
        Animation<double> secondaryAnimation,
        Widget child,
        ) =>
        SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(1, 0),
            end: Offset.zero,
          ).animate(animation),
          child: child,
        ),
  );
}