import 'package:flutter/material.dart';
import 'main.dart';

Widget mainNavigation() {
  return Container(
    margin: EdgeInsets.all(50.0),
    width: double.infinity,
    alignment: Alignment.topCenter,
    padding: new EdgeInsets.symmetric(vertical: 10.0),
    constraints: BoxConstraints.expand(
        width: 600.0,
    ),
    child:
    GridView.count(
      physics: const ScrollPhysics(),
      crossAxisCount: 3,
      children: [
        navButton("1", "blank"),
        navButton(null, "blank"),
        navButton("1", "power"),

        navButton("1", "chup"),
        navButton("1", "up"),
        navButton("1", "volup"),

        navButton("0", "left"),
        navButton(null, "select"),
        navButton("1", "right"),

        navButton("0", "chdown"),
        navButton("0", "down"),
        navButton("0", "voldown"),

        navButton("0", "return"),
        navButton("0", "menu"),
        navButton("0", "mute"),
      ],
    ),
  );
}

Widget navButton(String command, String iconName) {
  if (command == null)
  {
      return MaterialButton(
        onPressed: null,
        child: Image.asset('assets/images/'+iconName+'.png'),
      );
  }
  else
  {
    return RawMaterialButton(
      onPressed: (){sendCommand(command);},
      shape: new CircleBorder(),
      child: Image.asset('assets/images/'+iconName+'.png'),
    );
  }

}