import 'main.dart';
import 'package:flutter/material.dart';


Widget mainNavigation() {
  
  return GridView.count(
    padding: const EdgeInsets.all(60.0),
    crossAxisCount: 3,
    children: [
      navButton("1", "chup"),
      navButton("1", "up"),
      navButton("1", "volup"),

      navButton("0", "left"),
      navButton(null, "select"),
      navButton("1", "right"),

      navButton("0", "chdown"),
      navButton("0", "down"),
      navButton("0", "voldown"),
    ],
  );
}

Widget navButton(String command, String iconName) {
  if (command == null)
  {
      return MaterialButton(
        child: Image.asset('assets/images/'+iconName+'.png'),
      );
  }
  else
  {
    return MaterialButton(
      onPressed: (){sendCommand(command);},
      child: Image.asset('assets/images/'+iconName+'.png'),
    );
  }

}