import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

Color bgColor = const Color(0xff252528);

void main() => runApp(new OneRemote());

class OneRemote extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String url = 'http://192.168.0.134/digital/5/';

  Future sendCommand(String command) async {
    await http.get(Uri.encodeFull(url + command));
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: bgColor,
      body: GridView.count(
        padding: const EdgeInsets.all(60.0),
        crossAxisCount: 3,
          children: [
//            FlatButton(
//              onPressed: null,
//            ),
            FlatButton(
              onPressed: null,
              child: Image.asset('assets/images/chup.png'),
            ),
            FlatButton(
              onPressed: (){sendCommand("1");},
              child: Image.asset('assets/images/up.png'),
            ),
            FlatButton(
              onPressed: null,
              child: Image.asset('assets/images/volup.png'),
            ),
//            FlatButton(
//              onPressed: null,
//            ),
//            FlatButton(
//              onPressed: null,
//            ),
            FlatButton(
              onPressed: (){sendCommand("0");},
              child: Image.asset('assets/images/left.png'),
            ),
            FlatButton(
              onPressed: null,
              child: Image.asset('assets/images/select.png'),
            ),
            FlatButton(
              onPressed: (){sendCommand("1");},
              child: Image.asset('assets/images/right.png'),
            ),
//            FlatButton(
//              onPressed: null,
//            ),
//            FlatButton(
//              onPressed: null,
//            ),
            FlatButton(
              onPressed: null,
              child: Image.asset('assets/images/chdown.png'),

            ),
            FlatButton(
              onPressed: (){sendCommand("0");},
              child: Image.asset('assets/images/down.png'),
            ),
            FlatButton(
              onPressed: null,
              child: Image.asset('assets/images/voldown.png'),

            ),
          ],
      ),
    );
  }
}


