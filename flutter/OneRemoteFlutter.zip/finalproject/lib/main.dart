import 'package:flutter/material.dart';
import 'package:finalproject/controlPage/controlsDrawer.dart';
import 'package:finalproject/SettingsPage/settingsPage.dart';
import 'package:finalproject/firebaseAuth/authPage.dart';
import 'package:finalproject/RoutinesPage/routinesPage.dart';
import 'package:finalproject/styling.dart';


final items = List<String>.generate(10000, (i) => "Item $i");

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OneRemote',
      theme: ThemeData(
        primaryColor: bgColor,
      ),
      home: Scaffold(
        body: BodyLayout(),
        backgroundColor: bgColor,
      ),
    );
  }
}

class BodyLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return _mainMenu(context);
  }
}

Widget _mainMenu(BuildContext context) {
  return ListView(
    children: <Widget>[
      Container(
        margin: EdgeInsets.all(20.0),
        padding: EdgeInsets.all(20.0),
        constraints: BoxConstraints(maxWidth: 766.0, minWidth: 119.0),
        alignment: Alignment.topCenter,
        child: Image.asset('assets/images/oneRemote.png'),
      ),
      mainMenuButton(context, "Devices", Icons.settings_remote, ControlsDrawer()),
      mainMenuButton(context, "Routines", Icons.star_border, RoutinesPage()),
      mainMenuButton(context, "Settings", Icons.tune, SettingsPage()),
      mainMenuButton(context, "Sign Out", Icons.move_to_inbox, AuthPage()),
    ],
  );
}

Widget mainMenuButton(BuildContext context, String label, IconData labelIcon, var Page) {
  return new Container(
    width: MediaQuery.of(context).size.width,
    margin: EdgeInsets.only(top: 10.0, left: 25.0, right: 25.0),

    decoration: new BoxDecoration(
      color: buttonColor,
      borderRadius: new BorderRadius.circular(25.0),
    ),
    child: new ListTile(
        leading: Icon(labelIcon, color: Colors.white, size: 33.0),

        title: Text(label,
            style: TextStyle(color: Colors.white, fontSize:28.0)),
        onTap: () {
          Navigator.push(context, SlideRightRoute(page: Page));

        }),
  );
}
