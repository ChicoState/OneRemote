import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'controls.dart';

String url = 'http://192.168.0.134/digital/5/';
Color bgColor = const Color(0xff252528);

void main() => runApp(new OneRemote());

class OneRemote extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: bgColor,
      body:
      mainNavigation(),
    );
  }
}

Future sendCommand(String command) async {
  await http.get(Uri.encodeFull(url + command));
}