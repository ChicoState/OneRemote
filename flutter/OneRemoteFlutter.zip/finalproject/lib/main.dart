import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'controls.dart';
import 'package:page_indicator/page_indicator.dart';

String url = 'http://192.168.0.134/digital/5/';
Color bgColor = const Color(0xff252528);
String deviceName = "Optoma HD142x";

void main() => runApp(new OneRemote());

class OneRemote extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  PageController controller;

  @override
  void initState() {
    super.initState();
    controller = PageController();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  int counter = 0;

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: bgColor,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: [
            IconButton(
                icon: Icon(
              Icons.tv,
              color: Colors.white,
              size: 34.0,
            )),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: new Text(
                deviceName,
              ),
            ),
          ],
        ),
      ),
      body: new Container(
        color: Colors.black,
        child: Container(
          constraints: BoxConstraints.expand(
            width: 600.0,
          ),
          child: PageIndicatorContainer(
            pageView: PageView(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: [0.1, 0.5, 0.7, 0.9],
                      colors: [
                        Colors.indigo[800],
                        Colors.indigo[700],
                        Colors.indigo[600],
                        Colors.indigo[400],
                      ],
                    ),
                  ),
                  child: mainNavigation(),
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: [0.1, 0.5, 0.7, 0.9],
                      colors: [
                        Colors.indigo[800],
                        Colors.indigo[700],
                        Colors.indigo[600],
                        Colors.indigo[400],
                      ],
                    ),
                  ),

                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: [0.1, 0.5, 0.7, 0.9],
                      colors: [
                        Colors.indigo[800],
                        Colors.indigo[700],
                        Colors.indigo[600],
                        Colors.indigo[400],
                      ],
                    ),
                  ),
                  child: numPad(),
                ),
              ],
              controller: controller,
            ),
            align: IndicatorAlign.bottom,
            length: 3,
            indicatorSpace: 10.0,
          ),
        ),
      ),
    );
  }
}

Future sendCommand(String command) async {
  await http.get(Uri.encodeFull(url + command));
}
