import 'package:flutter/material.dart';
import 'package:finalproject/controlPage/firstDevice.dart';

Color windowColor = const Color(0x64000000);

Widget mainNavigation() {
  return Container(

    margin: EdgeInsets.only(top: 20.0, bottom: 40.0, left: 35.0, right: 35.0),

//    width: double.infinity,
    color: windowColor,
    alignment: Alignment.topCenter,
    padding: new EdgeInsets.symmetric(vertical: 0.0, horizontal: 25.0),
//    constraints: BoxConstraints.expand(
//        width: 600.0,
//    ),
    child:
    GridView.count(
      padding: EdgeInsets.only(top: 0.0),
      physics: const ScrollPhysics(),
      crossAxisCount: 3,
      children: [
        navButton("1", "blank"),
        navButton(null, "blank"),
        navButton("1", "power"),

        navButton("1", "chup"),
        navButton("1", "up"),
        navButton("1", "volup"),

        navButton("0", "left"),
        navButton(null, "select"),
        navButton("1", "right"),

        navButton("0", "chdown"),
        navButton("0", "down"),
        navButton("0", "voldown"),

        navButton("0", "return"),
        navButton("0", "menu"),
        navButton("0", "mute"),

        navButton("0", "rewind"),
        navButton("0", "playpause"),
        navButton("0", "fastforward"),
      ],
    ),
  );
}

Widget numPad() {
  return Container(

    margin: EdgeInsets.only(top: 20.0, bottom: 40.0, left: 35.0, right: 35.0),

    width: double.infinity,
    color: windowColor,
    alignment: Alignment.topCenter,
    padding: new EdgeInsets.symmetric(vertical: 0.0, horizontal: 25.0),
    constraints: BoxConstraints.expand(
      width: 600.0,
    ),
    child:
    GridView.count(
      physics: const ScrollPhysics(),
      crossAxisCount: 3,
      children: [
        navButton("1", "1"),
        navButton("2", "2"),
        navButton("3", "3"),

        navButton("4", "4"),
        navButton("5", "5"),
        navButton("6", "6"),

        navButton("7", "7"),
        navButton("8", "8"),
        navButton("9", "9"),
      ],
    ),
  );
}

Widget navButton(String command, String iconName) {
  if (command == null)
  {
      return MaterialButton(
        onPressed: null,
        child: Image.asset('assets/images/'+iconName+'.png'),
      );
  }
  else
  {
    return RawMaterialButton(
      onPressed: (){sendCommand(command);},
      shape: new CircleBorder(),
      child: Image.asset('assets/images/'+iconName+'.png'),
    );
  }

}