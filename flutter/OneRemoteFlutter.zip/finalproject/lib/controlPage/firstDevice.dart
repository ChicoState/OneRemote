import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:page_indicator/page_indicator.dart';

import 'package:finalproject/controlPage/deviceButtons.dart';


String url = 'http://192.168.0.134/digital/5/';
Color bgColor = const Color(0xff252528);



class FirstFragment extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new MyFirstFragment(),
    );
  }
}

class MyFirstFragment extends StatefulWidget {
  @override
  _MyFirstFragmentState createState() => new _MyFirstFragmentState();
}

class _MyFirstFragmentState extends State<MyFirstFragment> {
  PageController controller;

  @override
  void initState() {
    super.initState();
    controller = PageController();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  int counter = 0;

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: new Container(
        color: Colors.black,
        child: Container(
          constraints: BoxConstraints.expand(
            width: 600.0,
          ),
          child: PageIndicatorContainer(
            pageView: PageView(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: [0.1, 0.5, 0.7, 0.9],
                      colors: [
                        Colors.indigo[800],
                        Colors.indigo[700],
                        Colors.indigo[600],
                        Colors.indigo[400],
                      ],
                    ),
                  ),
                  child: mainNavigation(),
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: [0.1, 0.5, 0.7, 0.9],
                      colors: [
                        Colors.indigo[800],
                        Colors.indigo[700],
                        Colors.indigo[600],
                        Colors.indigo[400],
                      ],
                    ),
                  ),

                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: [0.1, 0.5, 0.7, 0.9],
                      colors: [
                        Colors.indigo[800],
                        Colors.indigo[700],
                        Colors.indigo[600],
                        Colors.indigo[400],
                      ],
                    ),
                  ),
                  child: numPad(),
                ),
              ],
              controller: controller,
            ),
            align: IndicatorAlign.bottom,
            length: 3,
            indicatorSpace: 10.0,
          ),
        ),
      ),
    );
  }
}

Future sendCommand(String command) async {
  await http.get(Uri.encodeFull(url + command));
}