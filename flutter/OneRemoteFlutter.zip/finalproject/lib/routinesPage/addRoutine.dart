import 'package:flutter/material.dart';
import 'package:finalproject/styling.dart';
import 'package:finalproject/routinesPage/routinesData.dart';
class AddRoutine extends StatefulWidget {


  @override
  _AddRoutineState createState() => _AddRoutineState();
}

class _AddRoutineState extends State<AddRoutine> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: AppBar(
          title: Text("Add Routine"),
        ),
        backgroundColor: bgColor,
        body: new Column(
          children: <Widget>[
            whiteText("Add Routine"),
      RaisedButton(
        onPressed: (){
          routineList.add(  Routine(name: 'Added Routine', commands: 'isa.tusa@me.com'));
          Navigator.pop(context);
        },
        color: Colors.yellow,
        disabledTextColor: Colors.grey,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0)
        ),
        elevation: 20.0,
        splashColor: Colors.green,
        highlightColor: Colors.red,
        highlightElevation: 1.0,
        child: Text("Add Routine"),
      ),

          ],
        )
    );
  }
}