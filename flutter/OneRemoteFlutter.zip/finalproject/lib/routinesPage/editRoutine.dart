import 'package:flutter/material.dart';
import 'package:finalproject/styling.dart';
import 'package:finalproject/routinesPage/routinesData.dart';

class EditRoutine extends StatefulWidget {

  @override
  _EditRoutineState createState() => _EditRoutineState();
}

class _EditRoutineState extends State<EditRoutine> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: AppBar(
          title: Text("Edit Routine"),
        ),
        backgroundColor: bgColor,
        body: new Column(
          children: <Widget>[
            whiteText("Edit Routine"),

          ],
        )
    );
  }
}