class Routine {
  Routine({this.name, this.commands});
  final String name;
  final String commands;
}

List<Routine> routineList = [
  Routine(name: 'Routine 1', commands: 'isa.tusa@me.com'),
  Routine(name: 'Racquel Ricciardi', commands: 'racquel.ricciardi@me.com'),

];