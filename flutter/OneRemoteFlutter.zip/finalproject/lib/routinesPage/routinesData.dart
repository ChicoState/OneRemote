class Routine {
  final String name;
  final String commands;

  const Routine({this.name, this.commands});
}

const RoutineData = <Routine>[
  Routine(
      name: 'Routine 1',
      commands:'Commands for routine 1'
  ),
  Routine(
      name: 'Routine 2',
      commands:'Commands for routine 2'
  ),

];