import 'package:flutter/material.dart';
import 'package:finalproject/routinesPage/routinesData.dart';
import 'package:finalproject/main.dart';
import 'package:finalproject/styling.dart';
import 'package:finalproject/routinesPage/addRoutine.dart';
import 'package:finalproject/routinesPage/editRoutine.dart';
class RoutinesPage extends StatefulWidget {
  const RoutinesPage({ Key key }) : super(key: key);

  @override
  _RoutinesPageState createState() => _RoutinesPageState();
}
class _RoutinesPageState extends State<RoutinesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          title: Text("Routines"),
        ),
        body: new Column(
          children: <Widget>[
            Expanded(
              child: SizedBox(
                height: 200.0,
                child: Container(
                  child: _buildContent(context),
                ),
              ),
            ),
            new RaisedButton(
              onPressed: () {
                setState(() {
                  Navigator.push(context, SlideRightRoute(page: AddRoutine()));

                });
              },
              color: Colors.green,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0)),
              elevation: 20.0,
              splashColor: Colors.greenAccent,
              highlightColor: Colors.red,
              highlightElevation: 1.0,
              child: whiteText("Add Routine"),
            ),
          ],
        ));
  }
}


Widget _buildContent(BuildContext context) {
  return ListView.builder(
      itemCount: routineList.length,
      itemBuilder: (BuildContext content, int index) {
        Routine routine = routineList[index];
        return RoutinesListTile(context, routine);
      });
}

class RoutinesListTile extends ListTile {
  RoutinesListTile(BuildContext context, Routine routine)
      : super(
          title: whiteText(routine.name),
          leading: CircleAvatar(child: whiteText(routine.name[0])),
          onTap: () {
            Navigator.push(context, SlideRightRoute(page: EditRoutine()));
          },
        );
}
