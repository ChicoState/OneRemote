import 'package:flutter/material.dart';
import 'routinesData.dart';

class RoutinesPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Routines"),
        ),
        body: Test()
    );
  }

}
class Test extends StatelessWidget {
  @override
  Widget build (BuildContext context) {
    return new Scaffold(
        body: new Column(
          children: <Widget>[
            Expanded(
              child: SizedBox(
                height: 200.0,
                child: RoutineList(RoutineData)
              ),
            ),
            new Text("text"),

          ],
        )
    );
  }
}
class RoutineList extends StatelessWidget {

  final List<Routine> _routines;

  RoutineList(this._routines);

  @override
  Widget build(BuildContext context) {
    return ListView(
        padding: EdgeInsets.symmetric(vertical: 8.0),
        children:
        _buildContactList(),
    );
  }

  List<_RoutineListItem> _buildContactList() {
    return _routines.map((contact) => _RoutineListItem(contact))
        .toList();
  }

}

class _RoutineListItem extends ListTile {

  _RoutineListItem(Routine routine) :
        super(
          title : Text(routine.name),
          subtitle: Text(routine.commands),
          leading: CircleAvatar(
              child: Text(routine.name[0])
          )
      );

}