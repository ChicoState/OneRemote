
/* strerror.h */

char *strerror(/* int err */);
